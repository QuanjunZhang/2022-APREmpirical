该程序仅存在一处错误，存在1个测试用例可以触发该错误。
src/test/java包含了整个程序的所有测试用例，仅运行它既可触发触发错误。

触发错误的用例：
Failing tests: 1
  - org.apache.commons.math.analysis.solvers.BrentSolverTest::testBadEndpoints

